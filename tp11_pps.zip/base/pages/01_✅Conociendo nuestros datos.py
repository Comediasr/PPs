import pandas as pd
import streamlit as st

aeropuertos =  pd.read_csv('ar-airports.csv')
st.title("Aeropuertos Dataset")
st.subheader("Aca podemos ver como esta formado el conjunto de datos que estamos investigando, sus columnas, los tipos de datos y como se dividen")
filas, columnas = aeropuertos.shape
with st.expander("¿Cuántas filas y columnas tiene el dataset?"):
    filas, columnas = aeropuertos.shape
    st.write(f'Tiene { filas} filas y {columnas} columnas')
    st.write("Como podemos ver el conjunto de datos esta formado por un total 956 registros de aeropuertos cuyos datos se dividen en 24 columnas")
    
    
nombres_type = aeropuertos['type'].unique()
cant_type = len(aeropuertos['type'].unique())


with st.expander("¿Cuáles son los nombres de las columnas ?"):
   
    st.write(aeropuertos.columns)
    st.write("Como podemos ver en los nombres de las columnas se ve que este conjunto de datos esta registrado en ingles, algunas son bastantes obvias como name o type y otras mas complejas como scheduled service o gps_code, en esta ocasion solo nos vamos a centrar en las columnas type y region_name")

with st.expander("¿Que datos tiene la columna type?"):
    st.write(nombres_type)
with st.expander("¿Cuántos son los valores únicos de la columna **type**?"):
    st.write(cant_type)

        