import streamlit as st
st.image('images/banner.png')

st.title("Análisis de Datos en la Facultad de Informática")
st.subheader(" Con Python🐍")
st.write("Bienvenidos, en esta ocasion mediante nuestra pagina interactiva podremos descubrir como funcionan los conjuntos de datos y como estan formados, Nuestra pagina permite conocer mejor los aeropuertos de Argentina de una manera sencilla e interactiva. A través de gráficos, se podrá observar cuántos aeropuertos hay en cada provincia y qué tipos de aeropuertos existen. También se podrá consultar información general sobre los datos utilizados y explorar un mapa que muestra la ubicación de distintos aeropuertos del país, con la posibilidad de elegir cuáles ver según su tamaño. El objetivo es que cualquier persona, aunque no tenga conocimientos de informática o análisis de datos, pueda explorar la información, comprenderla fácilmente y descubrir datos interesantes sobre nuestro país.")
