import streamlit as st
import pandas as pd

import streamlit as st
import plotly.express as px


aeropuertos = pd.read_csv('ar-airports.csv')

st.title("Gráfico")
#fig,ax = plt.subplots()
# Crear el gráfico de barras
filtro = aeropuertos['region_name'].value_counts()
fig = px.bar(
    filtro,
    x=filtro,
    title="Mi gráfico de barras"
)


# Agregar etiquetas y título
#ax.set_xlabel('Provincia')
#ax.set_ylabel('Cantidad')
#ax.set_title('Cantidad de Lagos por provincia')

# Mostrar el gráfico
st.plotly_chart(fig)
