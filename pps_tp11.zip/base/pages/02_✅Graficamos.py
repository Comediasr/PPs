import streamlit as st
import pandas as pd
import plotly.express as px

aeropuertos = pd.read_csv('ar-airports.csv')
st.title("Graficos")

# Gráfico de barras
st.subheader("Gráfico de barras")

filtro = aeropuertos['region_name'].value_counts().reset_index()
filtro.columns = ['Provincia', 'Cantidad']

fig = px.bar(
    filtro,
    x='Cantidad',
    y='Provincia',
    title="Cantidad de Aeropuertos por Provincia"
)

st.plotly_chart(fig)
st.markdown("Este grafico de **barras** los que nos muestra es la cantidad de aeropuertos por provincia, como podemos ver gran parte de los aeropuertos estan en la provincia de **Buenos Aires**, tambien podemos ver bastantes aeropuertos en provincias como **Cordoba** y **Santa Fe**, despues tenemos lo contrario, provincias las cuales tienen pocos aeropuertos como son **San Juan**, **La Rioja** y **Jujuy**.")

# Gráfico de torta
st.subheader("Gráfico de torta")

filtro = aeropuertos['type'].value_counts().reset_index()
filtro.columns = ['Tipo', 'Cantidad']

fig = px.pie(
    filtro,
    names='Tipo',
    values='Cantidad',
    title="Porcentajes de tipos de Aeropuertos"
)

st.plotly_chart(fig)
st.markdown("Este grafico de **torta** lo que nos muestra es la cantidad de porcentaje entre los tipos de aeropuertos, podemos ver que un gran porcentaje se lo lleva los aeropuertos **chicos** que son los que dominan en el mapa, tambien podemos ver una parte medianamente grande que son los **helipuertos** y hay tipos los cuales ni se pueden ver en el grafico a simple vista como los aeropuertos **grandes** o los **puertos de globos aerostaticos**.")
